package com.example.proyectoentrega2

class LoginActivity {
}